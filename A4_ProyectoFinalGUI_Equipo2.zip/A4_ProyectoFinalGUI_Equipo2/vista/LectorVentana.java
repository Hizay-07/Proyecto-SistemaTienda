package vista;

import java.awt.*;
public class LectorVentana{
	public LectorVentana(){}
	public int pasarEntero(TextField tfInt){
		int n=-1;
		try{
			n=Integer.parseInt(tfInt.getText());			
		}catch(NumberFormatException ex){
			System.err.println("*Valor no valido*");
			
		}
		return n;
	}

	public float pasarFloat(TextField tfFloat){
		float f=-1F;
		try{
			f=Float.parseFloat(tfFloat.getText());
		}catch(NumberFormatException ex){
			System.err.println("*Valor no valido*");
		}
		return f;
	}
}