package vista;

public class LectorDatosProducto extends Lector {
    public LectorDatosProducto() {
    }

    public int leerCantidad() {
        int cant;
        cant = leerEntero("Cantidad: ");
        return cant;
    }

    public Object[] leerDatosBusqueda() {
        Object[] producto = new Object[2];
        System.out.println("\nIngrese los datos del producto");
        producto[0] = leerCadena("Nombre: ");
        producto[1] = leerCadena("Codigo: ");
        return producto;
    }

    public Object[] leerDatosProducto() {
        Object[] producto = new Object[7];
        Object[] productoB = leerDatosBusqueda();
        producto[0] = productoB[0];
        producto[1] = productoB[1];
        producto[2] = leerFlotante("Precio de venta: ");
        producto[3] = leerEntero("Descuento: ");
        producto[4] = leerCadena("Descripcion: ");
        producto[5] = leerEntero("\nCantidad a agregar: ");
        return producto;
    }

    public Object[] leerDatosCantidad() {
        Object[] producto = new Object[3];
        Object[] productoB = leerDatosBusqueda();
        producto[0] = productoB[0];
        producto[1] = productoB[1];
        producto[3] = leerCadena("Cantidad: ");
        return producto;
    }
}