package vista;
import java.awt.*;
import java.awt.event.*;
import controlador.*;
public class VentanaProducto extends Frame{
	private LectorVentana lv=new LectorVentana();
	private Label lInstruccion,lNom,lCod,lPre,lDescu,lDescr,lCant;
	private TextField tfNom,tfCod,tfPre,tfDescu,tfDescr,tfCant;
	private Button bGuardar;
	private Panel pCentro,pSur;
	private String nom,cod,descr;
	private float pre;
	private int descu,cant;
    private ControladorProducto controlp;
	private Font fuente=new Font("Arial",Font.BOLD,16);
	public VentanaProducto(){
		super("Producto no electronico");
		setLayout(new BorderLayout());
		lInstruccion=new Label("Ingrese los datos del producto y presione Guardar");
		lInstruccion.setFont(fuente);
		add(lInstruccion,BorderLayout.NORTH);
		pCentro=_crearPCentro();
		add(pCentro,BorderLayout.CENTER);
		pSur=_crearPSur();
		add(pSur,BorderLayout.SOUTH);
		addWindowListener(new EscuchaVentana());
		bGuardar.addActionListener(new EscuchaAgregar());
		setSize(450,600);
		setVisible(false);
	}
    public void addControlador(ControladorProducto controlp){
        this.controlp = controlp;
    }
    public void mostrarVentana(){
        setVisible(true);
		setLocationRelativeTo(null);
    }
    public void cerrarVentana(){
        setVisible(false);
        dispose();
    }
	class EscuchaAgregar implements ActionListener{
		public void actionPerformed(ActionEvent e){
			nom=tfNom.getText();
			cod =tfCod.getText();
			pre=lv.pasarFloat(tfPre);
			descu=lv.pasarEntero(tfDescu);
			descr=tfDescr.getText();
			cant=lv.pasarEntero(tfCant);
			if(cant<0||descu<0||pre<0F){
				tfPre.selectAll();tfPre.setText("");
				tfDescu.selectAll();tfDescu.setText("");
				tfCant.selectAll();tfCant.setText("");
			}else{
				controlp.agregarProducto(nom, cod, pre, descu, descr,cant);
				cerrarVentana();
			}
		}
	}
	class EscuchaVentana implements WindowListener{
		public void windowClosing(WindowEvent e){
			cerrarVentana();
		}
		public void windowActivated(WindowEvent e){}
		public void windowClosed(WindowEvent e){}
		public void windowDeactivated(WindowEvent e){}
		public void windowDeiconified(WindowEvent e){}
		public void windowIconified(WindowEvent e){}
		public void windowOpened(WindowEvent e){}
	}
	
	private Panel _crearPCentro(){
		Panel p=new Panel(new GridLayout(12,1));
		lNom=new Label("Nombre:");lCod=new Label("Codigo:");
		lPre=new Label("Precio de venta:");lDescu=new Label("Descuento:");
		lDescr=new Label("Descripcion:");
		lCant=new Label("Cantidad a agregar:");
		tfNom=new TextField();tfCod=new TextField();
		tfPre=new TextField();tfDescu=new TextField();
		tfDescr=new TextField();tfCant=new TextField();
		Label[] lbs={lNom,lCod,lPre,lDescu,lDescr,lCant};
		TextField[] tfs={tfNom,tfCod,tfPre,tfDescu,tfDescr,tfCant};
		for(int i=0;i<tfs.length;i++){
			tfs[i].setBackground(Color.LIGHT_GRAY);
			tfs[i].setFont(fuente);
			lbs[i].setFont(fuente);
			p.add(lbs[i]);
			p.add(tfs[i]);
		}
		return p;
	}
	private Panel _crearPSur(){
		Panel p=new Panel(new FlowLayout(FlowLayout.RIGHT));
		bGuardar=new Button("Guardar");
		bGuardar.setBackground(Color.GREEN);
		bGuardar.setFont(fuente);
		p.add(bGuardar);
		return p;
	}
	
}
   