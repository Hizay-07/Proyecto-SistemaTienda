package vista;
import controlador.*;
public class Menu extends Lector{
    private int opcion1=0, opcion2=0, opcion3=0, opcion4=0;
    private ControladorTienda controlT;
    private ControladorProducto controlpr;
    private ControladorCliente controlc;
    private ControladorProveedor controlp;
    private ControladorProductoElectronico controlE;
    private ControladorVentas controlv;
    private VentanaCliente lectorc;
    private VentanaProveedor lectorv;
    private VentanaProducto lectorp;
    private VentanaProductoElectronico lectorpe;
    public void addControlador(ControladorTienda c,ControladorProducto cpr, ControladorProveedor cp, ControladorCliente controlc,ControladorProductoElectronico controlE,ControladorVentas controlv){
        this.controlT=c;
        this.controlpr=cpr;
        this.controlp=cp;
        this.controlc=controlc;
        this.controlE = controlE;
        this.controlv = controlv;
    }
    public void mostrarMenu(){
        String[] categorias={"Productos","Clientes","Proveedores","Facturas","Pedidos","Movimientos tienda","Salir"};
        String[] acciones1={"Agregar","Modificar","Eliminar","Consultar Todos","Consulta Especifica","Volver"};
        String[] acciones2={"Generar Nuevo","Mostrar todo","Volver"};
        String[] acciones3={"Agregar","Asignar Producto","Desasignar Producto","Modificar","Eliminar","Consultar Todos","Consulta Especifica","Volver"};
        String[] acciones4={"Ganancias totales","Surtir Tienda","Volver"};
        String acciones[]={""};
        cargarDatos();
        controlT.asignarNombre();
        do{
            System.out.print("Bienvenido a ");
            controlT.consultarTienda();
            System.out.println("\nCategorias\n");
            for(int i=0;i<categorias.length;i++)
            System.out.println("["+(i+1)+"] "+categorias[i]);
            opcion1=leerEntero("\nElige una categoria: ");
            if(opcion1>0 && opcion1<categorias.length){
                    do{
                        System.out.println("\nCategorias\\"+categorias[opcion1-1]+"\n");
                        if(opcion1<=2){
                            acciones=acciones1;  
                        }else if(opcion1==3){
                            acciones=acciones3;
                        }else if(opcion1>=4 && opcion1<=5){
                            acciones=acciones2;
                        }else  if(opcion1==6){
                            acciones=acciones4;
                        }
                        for(int i=0;i<acciones.length;i++){
                            System.out.println("["+(i+1)+"] "+acciones[i]);
                        }
                            opcion2=leerEntero("\nElige una accion: ");
                        if(opcion2>0 && opcion2<acciones.length){
                            System.out.println("\nCategorias\\"+categorias[opcion1-1]+"\\"+acciones[opcion2-1]+"\n");
                            switch(opcion1){
                                case 1: 
                                    if(opcion2<acciones.length)
                                    opcion3=leerEntero("[1] No electronico \n[2] Electronico \n[3] Cancelar \n\nElige una opcion: ");
                                    switch(opcion3){
                                        case 1:
                                            switch(opcion2){
                                                case 1: 
                                                VentanaProducto lectorp = new VentanaProducto();
                                                lectorp.addControlador(controlpr);
                                                controlpr.addVentana(lectorp);
                                                lectorp.mostrarVentana();
                                                break;
                                                case 2: controlpr.modificarProducto();break;
                                                case 3: controlpr.eliminarProducto();break;
                                                case 4: controlpr.consultarProducto();break;
                                                case 5: controlpr.consultarProductoEspecifico();break;
                                            }
                                        break;
                                        case 2:
                                            switch(opcion2){
                                                case 1:
                                                VentanaProductoElectronico lectorpe = new VentanaProductoElectronico();
                                                lectorpe.addControlador(controlE);
                                                controlE.addVentana(lectorpe);
                                                lectorpe.mostrarVentana(); 
                                                break;
                                                case 2: controlE.modificarProductoElectronico(); break;
                                                case 3: controlE.eliminarProductoElectronico(); break;
                                                case 4: controlE.consultarProductoElectronico(); break;
                                                case 5: controlE.consultarProductoElectronicoEspecifico(); break;
                                            }
                                        break;
                                    }
                                break;
                                case 2:
                                   switch(opcion2){
                                        case 1: 
                                        VentanaCliente lectorc=new VentanaCliente();
                                        lectorc.addControlador(controlc);
                                        controlc.addVentana(lectorc);
                                        lectorc.mostrarVentana();
                                        break;
                                        case 2: controlc.modificarCliente(); break;
                                        case 3: controlc.eliminarCliente(); break;
                                        case 4: controlc.consultarCliente(); break;
                                        case 5: controlc.consultarClienteEspecifico(); break;
                                    }                          
                                break;
                                case 3:
                                    switch(opcion2){
                                        case 1: 
                                        VentanaProveedor lectorv=new VentanaProveedor();
                                        lectorv.addControlador(controlp);
                                        controlp.addVentana(lectorv);
                                        lectorv.mostrarVentana();
                                        break;
                                        case 2: controlp.asignarProducto(); break;
                                        case 3: controlp.desasignarProducto(); break;
                                        case 4: controlp.modificarProveedor(); break;
                                        case 5: controlp.eliminarProveedor(); break;
                                        case 6: controlp.consultarProveedor(); break;
                                        case 7: controlp.consultarProveedorEspecifico(); break;
                                    }
                                break;
                                case 4:
                                    switch(opcion2){
                                        case 1: controlv.crearFactura(); break;
                                        case 2: controlv.consultarFacturas(); break;
                                    }
                                break;
                                case 5:
                                    switch(opcion2){
                                        case 1: controlv.crearPedido(); break;
                                        case 2: controlv.consultarPedidos(); break;
                                    }
                                break;
                                case 6: 
                                    switch(opcion2){
                                        case 1: controlv.gananciasTotales(); break;
                                        case 2: controlv.surtirTienda(); break;
                                    }
                                break;
                            }
                        }else if(opcion2<0 || opcion2 > acciones.length){
                            System.out.println("*Opcion no valida*");
                        }
                    }while(opcion2!=acciones.length); 
            }else if(opcion1==categorias.length){
                System.out.println("\nHasta luego");
            }else{
                System.out.println("*Opcion no valida*");
            }
        }while(opcion1!=categorias.length);
        guardarDatos();
    }
    public Object[] mostrarSubMenuModificaciones(int op){
        Object[] modificaciones=new Object[2];
        String[] categorias={""};
        switch(op){
            case 1: categorias= new String[] {"Nombre","Codigo","Precio venta","Descuento","Descripcion"}; break;
            case 2: categorias= new String[] {"Nombre","Correo","Direccion","RFC"}; break;
            case 3: categorias= new String[] {"Nombre","Correo","Telefono"}; break;
            case 4: categorias= new String[] {"Nombre","Codigo","Precio venta","Descuento","Descripcion","No.Serie"}; break;
        }
        for(int i=0;i<categorias.length;i++)
        System.out.println("["+(i+1)+"] "+categorias[i]);

            do{
                modificaciones[0]=leerEntero("Elige el dato: ");
                try{
                    modificaciones[1]=leerCadena("Nuevo "+categorias[((int)modificaciones[0])-1]+": ");
                }catch(ArrayIndexOutOfBoundsException e){
                    System.err.println("*Opcion no valida*");
                }
            }while((int)modificaciones[0]<1 || (int)modificaciones[0]>categorias.length);
        return modificaciones;
    }
    public int SubMenuFactura(){
        do{
            opcion4=leerEntero("\n[1] No electronico\n[2] Electronico\n[3] Listo \nElige una opcion: ");
        }while(opcion4<1 || opcion4>4);
        return opcion4;
    }
    public int SubMenuPedido(){ 
        do{
            opcion4=leerEntero("\n[1] No electronico\n[2] Electronico\n[3] Cancelar \nElige una opcion: ");
        }while(opcion4<1 || opcion4>4);
        return opcion4;
    }
    public int subMenuProveedor(){
        do{
            opcion4=leerEntero("\nAsignar Producto Ahora \n[1] Si [2] Despues\nOpcion: ");
        }while(opcion4!=1 && opcion4!= 2);
        return opcion4;
    }
    public void guardarDatos(){
        controlE.generarArchivoProductosE();
        controlc.guardarDatosCliente();
        controlp.generarArchivoProveedor();
        controlpr.guardarDatosProductos();
        controlv.generarArchivoFacturas();
        controlv.generarArchivoPedidos();
    }
    public void cargarDatos(){
        controlE.cargarDatosProductoElectronico();
        controlc.cargarDatosCliente();
        controlp.cargarDatosProveedor();
        controlpr.cargarDatosProducto();
        controlv.cargarDatosFacturas();
        controlv.cargarDatosPedidos();
    }
}