package vista;
public class EscritorDatosTienda{
    public EscritorDatosTienda(){
    }
    public void escribirDatosTienda(String tienda){
        System.out.println(tienda);
    }
}