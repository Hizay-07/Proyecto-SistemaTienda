package vista;
import java.awt.*;
import java.awt.event.*;
import controlador.ControladorProveedor;
public class VentanaProveedor extends Frame{
	private Label lInstruccion,lNombre,lCorreo,lTel;
	private TextField tfNombre,tfCorreo,tfTel;
	private Button bGuardar;
	private Panel pCentro,pSur;
	private ControladorProveedor controlp;
	private LectorVentana lv = new LectorVentana();
	private Font fuente=new Font("Arial",Font.BOLD,16);
	public void addControlador(ControladorProveedor controlp){
		this.controlp = controlp;
	}
	public VentanaProveedor(){
		super("Proveedor");
		setLayout(new BorderLayout());
		lInstruccion=new Label("Ingrese los datos del proveedor");
		lInstruccion.setFont(fuente);
		add(lInstruccion,BorderLayout.NORTH);
		pCentro=_crearPCentro();
		add(pCentro,BorderLayout.CENTER);
		pSur=_crearPSur();
		add(pSur,BorderLayout.SOUTH);
		addWindowListener(new EscuchaVentana());
		bGuardar.addActionListener(new alGuardar());
		setSize(400,300);
		setVisible(true);
	}
	public void mostrarVentana(){
		setLocationRelativeTo(null);
		setVisible(true);
	}
	class alGuardar implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String nombre = tfNombre.getText();
			String correo = tfCorreo.getText();
			String telefono = tfTel.getText();
			controlp.agregarProveedor(nombre,correo,telefono);
			cerrarVentana();
		}
	}
	public void cerrarVentana(){
		setVisible(false);
		dispose();
	}
	class EscuchaVentana implements WindowListener{
		public void windowClosing(WindowEvent e){
			cerrarVentana();
		}
		public void windowActivated(WindowEvent e){}
		public void windowClosed(WindowEvent e){}
		public void windowDeactivated(WindowEvent e){}
		public void windowDeiconified(WindowEvent e){}
		public void windowIconified(WindowEvent e){}
		public void windowOpened(WindowEvent e){}
	}
	public Panel _crearPCentro(){
		Panel p=new Panel(new GridLayout(6,1));
		lNombre=new Label("Nombre:");lCorreo=new Label("Correo:");
		lTel=new Label("Telefono:");
		tfNombre=new TextField();tfCorreo=new TextField();
		tfTel=new TextField();
		TextField[] tfs={tfNombre,tfCorreo,tfTel};
		Label[] lbs={lNombre,lCorreo,lTel};
		for(int i=0;i<tfs.length;i++){
			tfs[i].setFont(fuente);
			lbs[i].setFont(fuente);
			p.add(lbs[i]);
			p.add(tfs[i]);
		}
		return p;
	}
	public Panel _crearPSur(){
		Panel p=new Panel(new FlowLayout(FlowLayout.RIGHT));
		bGuardar=new Button("Guardar");
		bGuardar.setBackground(Color.GREEN);
		bGuardar.setFont(fuente);
		p.add(bGuardar);
		return p;
	}

}