package vista;
import java.util.Scanner;
import java.util.InputMismatchException;
public class Lector{
    protected Scanner sc=new Scanner(System.in);
    public int leerEntero(String msg){
        int n=0;
        Boolean leer;
        do{
            leer=false;
            System.out.print(msg);
            try{
                n=sc.nextInt();
                sc.nextLine();
            }catch(InputMismatchException e){
                System.err.println("*Valor no valido*");
                leer=true;
                sc.nextLine();
            }
        }while(leer);
        return n;
    }
    public float leerFlotante(String msg){
        float n=0;
        Boolean leer;
        do{
            leer=false;
            System.out.print(msg);
            try{
                n=sc.nextFloat();
                sc.nextLine();
            }catch(InputMismatchException e){
                System.err.println("*Valor no valido*");
                leer=true;
                sc.nextLine();
            }
        }while(leer);
        return n;
    }
    public String leerCadena(String msg){
        System.out.print(msg);
        String cad=sc.nextLine();
        return cad;
    }
}