package vista;
public class LectorDatosCliente extends Lector{
    public LectorDatosCliente(){
    }
    public Object[] leerDatosCliente(boolean leer){
        Object[] cliente = new Object[4];
        System.out.println("\nIngrese los datos del cliente");
        cliente[0] = leerCadena("Nombre: ");
        cliente[1] = leerCadena("Correo: ");
        if(leer){
            cliente[2] = leerCadena("Direccion: ");
            cliente[3] = leerCadena("RFC: ");
        }
        return cliente;
    }
}