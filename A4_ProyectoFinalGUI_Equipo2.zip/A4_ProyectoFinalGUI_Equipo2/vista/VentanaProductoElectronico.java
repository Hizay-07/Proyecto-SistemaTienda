package vista;

import java.awt.*;
import java.awt.event.*;
import controlador.*;
public class VentanaProductoElectronico extends Frame{
	private LectorVentana lv=new LectorVentana();
	private Label lInstruccion,lNom,lCod,lPre,lDescu,lDescr,lSer,lCant;
	private TextField tfNom,tfCod,tfPre,tfDescu,tfDescr,tfSer,tfCant;
	private Button bGuardar;
	private Panel pCentro,pSur;
    private ControladorProductoElectronico controlpe;
	private LectorDatosProductoElectronico lectorpe;
	private Font fuente=new Font("Arial",Font.BOLD,16);
	public VentanaProductoElectronico(){
		super("Producto electronico");
		setLayout(new BorderLayout());
		lInstruccion=new Label("Ingrese los datos del producto y presione Guardar");
		lInstruccion.setFont(fuente);
		add(lInstruccion,BorderLayout.NORTH);
		pCentro=_crearPCentro();
		add(pCentro,BorderLayout.CENTER);
		pSur=_crearPSur();
		add(pSur,BorderLayout.SOUTH);
		addWindowListener(new EscuchaVentana());
		bGuardar.addActionListener(new EscuchaAgregar());
		setSize(450,600);
		setVisible(true);
	}
    public void addControlador(ControladorProductoElectronico controlpe){
        this.controlpe = controlpe;
    }
    public void mostrarVentana(){
        setVisible(true);
		setLocationRelativeTo(null);
    }
    public void cerrarVentana(){
        setVisible(false);
        dispose();
    }
	class EscuchaAgregar implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String nombre = tfNom.getText();
			String codifo = tfCod.getText();
			float precio =lv.pasarFloat(tfPre);
			int descuento = lv.pasarEntero(tfDescu);
			String descripcion = tfDescr.getText();
			int serie = lv.pasarEntero(tfSer);
			int cant = lv.pasarEntero(tfCant);
			if(precio<0||descuento<0||serie<0||cant<0){
				tfPre.selectAll();tfPre.setText("");
				tfDescu.selectAll();tfDescu.setText("");
				tfCant.selectAll();tfCant.setText("");
				tfSer.selectAll();tfSer.setText("");
			}else{
				controlpe.agregarProductoElectronico(nombre, codifo, precio, descuento, descripcion,cant,serie);
				cerrarVentana();
			}
			

			
		}
	}
	class EscuchaVentana implements WindowListener{
		public void windowClosing(WindowEvent e){
			cerrarVentana();
		}
		public void windowActivated(WindowEvent e){}
		public void windowClosed(WindowEvent e){}
		public void windowDeactivated(WindowEvent e){}
		public void windowDeiconified(WindowEvent e){}
		public void windowIconified(WindowEvent e){}
		public void windowOpened(WindowEvent e){}
	}
	
	private Panel _crearPCentro(){
		Panel p=new Panel(new GridLayout(14,1));
		lNom=new Label("Nombre:");lCod=new Label("Codigo:");
		lPre=new Label("Precio de venta:");lDescu=new Label("Descuento:");
		lDescr=new Label("Descripcion:");lSer=new Label("No. de serie:");
		lCant=new Label("Cantidad a agregar:");
		tfNom=new TextField();tfCod=new TextField();
		tfPre=new TextField();tfDescu=new TextField();
		tfDescr=new TextField();tfSer=new TextField();
		tfCant=new TextField();
		Label[] lbs={lNom,lCod,lPre,lDescu,lDescr,lSer,lCant};
		TextField[] tfs={tfNom,tfCod,tfPre,tfDescu,tfDescr,tfSer,tfCant};
		for(int i=0;i<tfs.length;i++){
			tfs[i].setBackground(Color.LIGHT_GRAY);
			tfs[i].setFont(fuente);
			lbs[i].setFont(fuente);
			p.add(lbs[i]);
			p.add(tfs[i]);
		}
		return p;
	}
	private Panel _crearPSur(){
		Panel p=new Panel(new FlowLayout(FlowLayout.RIGHT));
		bGuardar=new Button("Guardar");
		bGuardar.setBackground(Color.GREEN);
		bGuardar.setFont(fuente);
		p.add(bGuardar);
		return p;
	}
	
}
  