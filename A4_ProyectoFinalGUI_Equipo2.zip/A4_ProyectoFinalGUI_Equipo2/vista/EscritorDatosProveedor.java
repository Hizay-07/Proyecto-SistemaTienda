package vista;
public class EscritorDatosProveedor {
    public EscritorDatosProveedor(){

    }
    public void escribirDatosProveedor(String proveedor){
        System.out.println("proveedores");
        System.out.println("----------------------------------------------------------------");
        System.out.println(proveedor);
    }
}
