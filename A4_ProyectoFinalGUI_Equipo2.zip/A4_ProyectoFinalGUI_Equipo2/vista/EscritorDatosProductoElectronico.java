package vista;

public class EscritorDatosProductoElectronico {
    public EscritorDatosProductoElectronico(){

    }
    public void escribirDatosProductosElectronicos(String productos){
        System.out.println("\nProductos Electronicos");
        System.out.println("----------------------------------------------------------------");
        System.out.println(productos);
    }
}
