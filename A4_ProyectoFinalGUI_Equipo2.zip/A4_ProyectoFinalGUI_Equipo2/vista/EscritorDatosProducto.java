package vista;
public class EscritorDatosProducto{
    public EscritorDatosProducto(){
    }
    public void escribirDatosProductos(String productos){
        System.out.println("\nProductos");
        System.out.println("----------------------------------------------------------------");
        System.out.println(productos);
    }
}