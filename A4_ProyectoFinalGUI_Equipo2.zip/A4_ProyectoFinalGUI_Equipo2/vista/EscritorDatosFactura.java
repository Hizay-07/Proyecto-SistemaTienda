package vista;
public class EscritorDatosFactura {
    public EscritorDatosFactura(){
    }
    public void EscribirDatosFactura(String factura){
        System.out.println("Facturas");
        System.out.println("----------------------------------------------------------------");
        System.out.println(factura);
    }
}
