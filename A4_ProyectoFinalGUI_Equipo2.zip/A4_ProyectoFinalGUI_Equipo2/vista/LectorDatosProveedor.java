package vista;
public class LectorDatosProveedor extends Lector {
    public LectorDatosProveedor(){

    }
    public Object[] leerDatosProveedor(boolean leer){
        Object[] proveedor = new Object[3];
        System.out.println("\nIngrese los datos del proveedor");
        proveedor[0] = leerCadena("Nombre: ");
        proveedor[1] = leerCadena("Correo: ");
        if(leer){
            proveedor[2] = leerCadena("Telefono: ");
        }

        return proveedor;
    }
}
