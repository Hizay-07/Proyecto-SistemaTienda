package vista;
public class LectorDatosTienda extends Lector{
    public LectorDatosTienda(){
    }
    public String leerDatosTienda(){
        String nombre;
        System.out.println("\nIngrese los datos de la tienda");
        nombre=leerCadena("Nombre: ");
        return nombre;
    }
}