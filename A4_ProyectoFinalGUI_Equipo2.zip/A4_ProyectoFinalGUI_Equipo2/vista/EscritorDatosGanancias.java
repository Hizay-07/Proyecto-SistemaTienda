package vista;

public class EscritorDatosGanancias {
    public EscritorDatosGanancias(){

    }
    public void escribirGanancias(float f){
        if(f>0){
            System.out.println("---Ganancias totales de la tienda---"+"\n\t $"+f+" pesos");
        }else{
            System.out.println("*La tienda no ha generado ninguna factura*");
        }
    }
}
