package vista;

public class EscritorDatosInversion {
    public EscritorDatosInversion(){

    }
    public void escribirTotalCompras(float i){
        if(i==0){
            System.out.println("*La tienda no ha invertido en pedidos/compras*");
        }else{
            System.out.println("*La tienda ha invertido un total de $"+i+" pesos en total*");
        }
    }
}
