package vista;
import java.awt.*;
import java.awt.event.*;
import controlador.ControladorCliente;
import modelo.*;
public class VentanaCliente extends Frame{
	private Label lInstruccion,lNombre,lCorreo,lDirec,lRfc;
	private TextField tfNombre,tfCorreo,tfDirec,tfRfc;
	private Button bGuardar;
	private Panel pCentro,pSur;
    private ControladorCliente controlc;
	private Font fuente=new Font("Arial",Font.BOLD,16);
    public void addControlador(ControladorCliente controlc){
        this.controlc = controlc;
    }
    public void cerrarVentana(){
        setVisible(false);
        dispose();
    }
    public void mostrarVentana(){
        setLocationRelativeTo(null);
    }
	public VentanaCliente(){
		super("Cliente");
		setLayout(new BorderLayout());
		lInstruccion=new Label("Ingrese los datos del cliente");
		lInstruccion.setFont(fuente);
		add(lInstruccion,BorderLayout.NORTH);
		pCentro=_crearPCentro();
		add(pCentro,BorderLayout.CENTER);
		pSur=_crearPSur();
		add(pSur,BorderLayout.SOUTH);
		addWindowListener(new EscuchaVentana());
		bGuardar.addActionListener(new alguardar());
		setSize(400,400);
		setVisible(true);
	}
	class alguardar implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String nombre = tfNombre.getText();
            String correo = tfCorreo.getText();
            String direccion = tfDirec.getText();
            String rfc = tfRfc.getText();
            controlc.agregarCliente(nombre,correo,direccion,rfc);
            cerrarVentana();
		}
	}

	class EscuchaVentana implements WindowListener{
		public void windowClosing(WindowEvent e){
			cerrarVentana();
		}
		public void windowActivated(WindowEvent e){}
		public void windowClosed(WindowEvent e){}
		public void windowDeactivated(WindowEvent e){}
		public void windowDeiconified(WindowEvent e){}
		public void windowIconified(WindowEvent e){}
		public void windowOpened(WindowEvent e){}
	}
	public Panel _crearPCentro(){
		Panel p=new Panel(new GridLayout(8,1));
		lNombre=new Label("Nombre:");lCorreo=new Label("Correo:");
		lDirec=new Label("Direccion:");lRfc=new Label("RFC:");
		tfNombre=new TextField();tfCorreo=new TextField();
		tfDirec=new TextField();tfRfc=new TextField();
		TextField[] tfs={tfNombre,tfCorreo,tfDirec,tfRfc};
		Label[] lbs={lNombre,lCorreo,lDirec,lRfc};
		for(int i=0;i<tfs.length;i++){
			tfs[i].setFont(fuente);
			lbs[i].setFont(fuente);
			p.add(lbs[i]);
			p.add(tfs[i]);
		}
		return p;
	}
	public Panel _crearPSur(){
		Panel p=new Panel(new FlowLayout(FlowLayout.RIGHT));
		bGuardar=new Button("Guardar");
		bGuardar.setBackground(Color.GREEN);
		bGuardar.setFont(fuente);
		p.add(bGuardar);
		return p;
	}

}