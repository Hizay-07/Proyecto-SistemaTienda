package vista;
public class EscritorDatosPedido {
    public EscritorDatosPedido(){
    }
    public void EscribirDatosPedido(String pedido){
        System.out.println("Pedidos");
        System.out.println("----------------------------------------------------------------");
        System.out.println(pedido);
    }
}
