package vista;

public class EscritorDatosCliente {
    public EscritorDatosCliente(){

    }
    public void escribirDatosCliente(String cliente){
        System.out.println("Clientes");
        System.out.println("----------------------------------------------------------------");
        System.out.println(cliente);
    }
}
