import modelo.operaciones.*;
import modelo.personas.*;
import modelo.productos.*;
import modelo.*;
import controlador.*;
import vista.*;
public class ClasePrincipal{
    public static final int cantidadProductos=10;
    public static final int cantidadPersonas=10;
    public static final int cantidadOperaciones=10;
    public static final int minStock=5;
    public static final int maxStock=30;
    public static void main(String[] args){
        Menu vista=new Menu();
        Tienda tienda=new Tienda();
        Producto[] productos= new Producto[cantidadProductos];
        ProductoElectronico[] productosE = new ProductoElectronico[cantidadProductos];
        Cliente[] clientes=new Cliente[cantidadPersonas];
        Proveedor[] proveedores=new Proveedor[cantidadPersonas];
        Factura[] facturas=new Factura[cantidadOperaciones];
        Pedido[] pedidos=new Pedido[cantidadOperaciones];
        ControladorTienda controlT= new ControladorTienda(tienda);
        ControladorProducto controlpr= new ControladorProducto(productos, minStock, maxStock);
        ControladorCliente controlc = new ControladorCliente(clientes);
        ControladorProductoElectronico controlpe = new ControladorProductoElectronico(productosE, minStock, maxStock);
        ControladorProveedor controlp = new ControladorProveedor(proveedores, controlpr,controlpe);
        ControladorVentas controlv = new ControladorVentas(facturas, pedidos,minStock,maxStock);
        
        controlpr.addVista(vista);
        controlc.addVista(vista);
        controlpe.addMenu(vista);
        controlpe.addControlador(controlv);
        controlp.addVista(vista);
        controlpr.addControlador(controlv);
        controlv.addMenu(vista);
        controlv.addControladores(controlc, controlpr, controlpe, controlT);
        vista.addControlador(controlT,controlpr, controlp, controlc,controlpe,controlv);
        vista.mostrarMenu();
    }
}