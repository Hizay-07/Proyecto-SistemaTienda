package controlador;
import java.io.*;
import vista.*;
import modelo.productos.*;

public class ControladorProductoElectronico {
    private Menu vista;
    private ProductoElectronico[] productoE;
    private int numProductos = 0;
    private int minStock;
    private int maxStock;

    private LectorDatosProductoElectronico lector = new LectorDatosProductoElectronico();
    private EscritorDatosProductoElectronico escritor = new EscritorDatosProductoElectronico();

    private ControladorVentas controlv= new ControladorVentas();
    private VentanaProductoElectronico lectorpe;
    public LectorDatosProductoElectronico getLector() {
        return lector;
    }

    public ControladorProductoElectronico(ProductoElectronico[] productoE, int minS, int maxS) {
        this.productoE = productoE;
        this.minStock = minS;
        this.maxStock = maxS;
    }
    public void addControlador(ControladorVentas cv){
        controlv=cv;
    }
    public void addMenu(Menu vista) {
        this.vista = vista;
    }
    public void addVentana(VentanaProductoElectronico lectorpe){
        this.lectorpe = lectorpe;
    }
    public void agregarProductoElectronico(String n, String c, float pv, int d, String ds, int ns, int ca){
        ProductoElectronico tmp=new ProductoElectronico(n,c,pv,d,ds,ns,ca);
        agregarProductoElectronico(tmp, ns);
    }
    public int getNumProductos() {
        return numProductos;
    }
    public void agregarProductoElectronico(ProductoElectronico np,int ns) {
        if (numProductos < productoE.length) {
            int pos = buscarProductoElectronico(np);
            if (pos != -1) {
                if (productoE[pos].getNoExistencias() + (int) ns<= maxStock) {
                    if ((int) ns > 0){
                        productoE[pos].setNoExistencias(productoE[pos].getNoExistencias() + (int) ns);
                        System.out.println("[ Producto agregado ]");
                    }
                    
                } else {
                    System.out.println("* El producto cuenta con " + productoE[pos].getNoExistencias() + " existencias *");
                    System.out.println("* Procura no sobrepasar el stock maximo de " + maxStock + " *");
                }
            } else {
                if((int)ns <= maxStock && (int)ns >0 ){
                    productoE[numProductos] = np;
                    numProductos++;  
                }else{
                    System.out.println("* Recuerda que el maximo por producto son "+maxStock+" *");
                }
            }
        } else {
            System.out.println("* Inventario lleno *");
        }
    }

    public void eliminarProductoElectronico() {
        int pos = buscarProductoElectronico();
        if (pos != -1) {
            productoE[pos].getProveedor().eliminarProducto(productoE[pos]);
            for(int i=pos; i<numProductos-1; i++){
                productoE[i]=productoE[i+1];
            }
            productoE[numProductos]=null;
            numProductos--;
            System.out.println("[Producto Electronico Eliminado]");
        } 
    }

    public void modificarProductoElectronico() {
        int pos = buscarProductoElectronico();
        if (pos != -1) {
            Object[] modificaciones = vista.mostrarSubMenuModificaciones(1);
            switch ((int) modificaciones[0]) {
                case 1: productoE[pos].setNombre((String) modificaciones[1]); break;
                case 2: productoE[pos].setCodigo((String) modificaciones[1]); break;
                case 3: productoE[pos].setPrecioVenta(Float.parseFloat((String) modificaciones[1]));break;
                case 4: productoE[pos].setDescuento(Integer.parseInt((String) modificaciones[1])); break;
                case 5: productoE[pos].setDescripcion((String) modificaciones[1]); break;
                case 6: productoE[pos].setNumSerie(Integer.parseInt((String) modificaciones[1])); break;
            }
        }
    }

    public int buscarProductoElectronico() {
        Object[] datos = lector.leerDatosBusqueda();
        for (int i = 0; i < numProductos; i++) {
            if (productoE[i].getNombre().equals((datos[0])) && productoE[i].getCodigo().equals(datos[1])) {
                return i;
            }
        }
        System.out.println("* No se encontro el producto *");
        return -1;
    }
    public int buscarProductoElectronico(String n, String cod){
        for(int i=0;i<numProductos;i++){
            if(productoE[i].getNombre().equals((n))&&productoE[i].getCodigo().equals(cod)){
                return i;
            }
        }
        return -1;
    }
    public void consultarProductoElectronico() {
        String productoString = "";
        for (int i = 0; i < numProductos; i++) {
            productoString += productoE[i] + "\n----------------------------------------------------------------\n";
        }
        escritor.escribirDatosProductosElectronicos(productoString);
    }

    public void consultarProductoElectronicoEspecifico() {
        int pos = buscarProductoElectronico();
        if(pos!=-1){
            String producto = "\n" + productoE[pos] + "\n----------------------------------------------------------------\n";
            escritor.escribirDatosProductosElectronicos(producto);
        }
    }

    public int buscarProductoElectronico(ProductoElectronico pe) {
        for (int i = 0; i < numProductos; i++) {
            if (pe.equals(productoE[i]))
                return i;
        }
        return -1;
    }

    public boolean eliminarProductoElectronico(int pos, int cant) {
        if(pos!=-1){
            if (productoE[pos].getNoExistencias() - cant >= 0) {
                productoE[pos].setNoExistencias(productoE[pos].getNoExistencias() - cant);
                if(productoE[pos].getNoExistencias()<= minStock){
                    llamarPedidoAutomatico(pos);
                }
                return true;
            } else {
                System.out.println("* No contamos con suficientes existencias *");
                System.out.println("* Contamos con: " + productoE[pos].getNoExistencias() + " *");
                System.out.println("* Y usted quiere retirar: " + cant + " *");
            }
        }
        return false;
    }

    public boolean agregarProductoElectronico(int pos, int cant) {
        if(productoE[pos].getNoExistencias() + cant <= maxStock){
            productoE[pos].setNoExistencias(productoE[pos].getNoExistencias()+cant);
            return true;
           }
           System.out.println("* Se esta excediendo el limite por de existencias *");
           System.out.println("* Contamos con: "+productoE[pos].getNoExistencias()+" *");
           System.out.println("* Y usted quiere agregar: "+ cant +" *");
           return false;

    }
    public ProductoElectronico getProductoElectronico(int i) {
        try {
            return productoE[i];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("* No se encotro el producto *");
            return null;
        }
    }
    public void llamarPedidoAutomatico(int pos){
        System.out.println("* Se sobrepaso el stock minimo de "+minStock+" *");
        if(productoE[pos].getProveedor() != null){
            int faltante= maxStock - productoE[pos].getNoExistencias();
            if(controlv.crearPedidoElectronico(pos, faltante))
            System.out.println("* Se realizo un pedido automatico de "+productoE[pos].getNombre()+" <"+productoE[pos].getCodigo()+"> de "+faltante+" *");
        }else{
            System.out.println("* No se pudo hacer un pedido automatico *");
            System.out.println("* Por favor, asignar un proveedor al producto *");
            
        }
    }
    public void addProductoElectronico(ProductoElectronico pe){
        if(numProductos<productoE.length){
            productoE[numProductos] = pe;
            numProductos++;
        }
    }
    public void cargarDatosProductoElectronico(){
        ProductoElectronico pe;
        try{
            FileInputStream fis = new FileInputStream("ProductosElectronicos.obj");
            ObjectInputStream oos = new ObjectInputStream(fis);

            while(fis.available()>0){
                pe = (ProductoElectronico)oos.readObject();
                addProductoElectronico(pe);
            }
            oos.close();
        }catch(FileNotFoundException fe){
            System.out.print(" ");
        }catch(EOFException eo){
            System.err.println(eo);
        }catch(IOException ie){
            System.err.println(ie);
        }catch(ClassNotFoundException cl){
            System.err.println(cl);
        }
    }
    public void generarArchivoProductosE(){
        try{
            File f = new File("ProductosElectronicos.obj");
            File f2 = new File("aux3.obj");
            if(numProductos>0){
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));
                for(int i=0;i<numProductos;i++){
                    oos.writeObject(productoE[i]);
                }
                oos.flush();
                oos.close();
                f.delete();
                f2.renameTo(f);
            }else{
                f.delete();
                f2.renameTo(f);
            }
        }catch(IOException ie){
            System.err.println(ie);
        }
    }

}
