package controlador;
import java.io.*;
import vista.*;
import modelo.personas.Cliente;
public class ControladorCliente {
        private Menu vista;
        private int numClientes=0;
        private LectorDatosCliente lector = new LectorDatosCliente();
        private EscritorDatosCliente escritor= new EscritorDatosCliente();
        private Cliente[] clientes;
        private VentanaCliente lectorc;
        public ControladorCliente(Cliente[] clientes){
            this.clientes = clientes;
        }
        public void addVista(Menu vista){
            this.vista = vista;
        }
        public void addVentana(VentanaCliente lectorc){
            this.lectorc=lectorc;
        }
        public void agregarCliente(String n, String c, String d, String r){
            if(numClientes<10){
                Cliente aux = new Cliente(n, c, d, r);
                if(!(comprobacionCliente(aux))){
                    clientes[numClientes] = aux;
                    numClientes++;
                    System.out.println("[Cliente Agregado]");
                }else{
                    System.out.println("*Este cliente ya esta registrado*");
                }
            }else{
                System.out.println("*No se pueden agregar mas clientes*");
            }
        }

        public boolean comprobacionCliente (Cliente c){
            for(int i=0;i<numClientes;i++){
                if(clientes[i].equals(c)){
                    return true;
                }
            }
            return false;
        }
        public void modificarCliente(){
            int pos = buscarCliente();
            if(pos!=-1){
                Object[] modificaciones = vista.mostrarSubMenuModificaciones(2);
                switch((int)modificaciones[0]){
                    case 1: this.clientes[pos].setNombre((String)modificaciones[1]); break;
                    case 2: this.clientes[pos].setCorreo((String)modificaciones[1]); break;
                    case 3: this.clientes[pos].setDireccion((String)modificaciones[1]); break;
                    case 4: this.clientes[pos].setRFC((String)modificaciones[1]); break;
                }
            }
        }
        public void eliminarCliente(){
            if(numClientes>0){
                int pos=buscarCliente();
                if(pos!=-1){
                    for(int i=pos;i<numClientes-1;i++){
                        clientes[i] = clientes[i+1];
                    }
                    clientes[numClientes-1] = null;
                    numClientes--;   
                    System.out.println("[ Cliente Eliminado ]");
                }
            }else{
                System.out.println("* No hay clientes registrados *");
            }
        }
        public void consultarCliente(){
            String clienteString="";
            for(int i=0;i<numClientes;i++){
                clienteString+=clientes[i]+"\n----------------------------------------------------------------\n";
            }
            escritor.escribirDatosCliente(clienteString);
        }
        public void consultarClienteEspecifico(){
            int pos=buscarCliente(); 
             if(pos !=-1){
                String cliente=""+clientes[pos];
                escritor.escribirDatosCliente(cliente); 
             }
        }
        public int buscarCliente(){
            Object[] datos = lector.leerDatosCliente(false);
             for(int i=0;i<numClientes;i++){
                if(clientes[i].getNombre().equals(datos[0])&&clientes[i].getCorreo().equals(datos[1])){
                    return i;
                }
            }
            System.out.println("* No se encontro el cliente *");
            return -1;
        }  
        public Cliente getCliente(){
            int pos = buscarCliente();
            try{
                return clientes[pos];
            }catch(ArrayIndexOutOfBoundsException e){
                System.err.println("*No se econtro el cliente*");
                return null;
            }
        }
        public void agregarCliente(Cliente cl){
            if(numClientes<clientes.length){
                clientes[numClientes] = cl;
                numClientes++;
            }
        }
        public void cargarDatosCliente(){
            Cliente c;
            try{
                FileInputStream fis = new FileInputStream("Clientes.obj");
                ObjectInputStream ois = new ObjectInputStream(fis);
                while(fis.available()>0){
                    c = (Cliente)ois.readObject();
                    agregarCliente(c);
                }
                ois.close();

            }catch(FileNotFoundException fe){
                System.err.print("");
            }catch(EOFException eo){
                System.err.println(eo);
            }catch(IOException ie){
                System.err.println(ie);
            }catch(ClassNotFoundException cl){
                System.err.println(cl);
            }
        }
        public void guardarDatosCliente(){
            File f = new File("Clientes.obj");
            File f2 = new File("aux.obj");

            try{
                if(this.numClientes>0){
                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));
                    for(int i=0;i<numClientes;i++){
                        oos.writeObject(clientes[i]);
                    }
                    oos.flush();
                    oos.close();
                    f.delete();
                    f2.renameTo(f);
                }else{
                    f.delete();
                    f2.renameTo(f);
                }
            }catch(IOException ie){
                System.err.println(ie);
            }
        }
}