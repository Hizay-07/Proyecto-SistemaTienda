package controlador;
import java.io.*;
import vista.*;
import modelo.personas.Proveedor;

public class ControladorProveedor {
    private int numProveedores = 0;
    private Proveedor[] proveedores;
    private Menu vista;

    private LectorDatosProveedor lector = new LectorDatosProveedor();
    private EscritorDatosProveedor escritor = new EscritorDatosProveedor();
    private ControladorProducto controlp;
    private ControladorProductoElectronico controlpe;
    private VentanaProveedor lectorv;

    public ControladorProveedor(Proveedor[] proveedores, ControladorProducto controlp,
            ControladorProductoElectronico controlpe) {
        this.proveedores = proveedores;
        this.controlp = controlp;
        this.controlpe = controlpe;
    }

    public void addVista(Menu vista) {
        this.vista = vista;
    }
    public void addVentana(VentanaProveedor lectorv){
        this.lectorv=lectorv;
    }
    public void agregarProveedor(String n, String c, String t){
        if(numProveedores<10){
            Proveedor aux = new Proveedor(n, c, t);
            if(!(comprobacionProveedor(aux))){
                proveedores[numProveedores] = aux;
                numProveedores++;
                System.out.println("[Proveedor Agregado]");
            }else{
                System.out.println("*Este proveedor ya esta registrado*");
            }
        }else{
            System.out.println("*No se pueden agregar mas proveedores");
        }
    }


    public boolean comprobacionProveedor(Proveedor p) {
        for (int i = 0; i < numProveedores; i++) {
            if (proveedores[i].equals(p)) {
                return true;
            }
        }
        return false;
    }

    public void modificarProveedor() {
        int pos = buscarProveedor();
        if (pos != -1) {
            Object[] modificaciones = vista.mostrarSubMenuModificaciones(3);
            switch ((int) modificaciones[0]) {
                case 1:
                    proveedores[pos].setNombre((String) modificaciones[1]);
                    break;
                case 2:
                    proveedores[pos].setCorreo((String) modificaciones[1]);
                    break;
                case 3:
                    proveedores[pos].setTelefono((String) modificaciones[1]);
                    break;
            }
        }
    }

    public void eliminarProveedor() {
        if (numProveedores > 0) {
            int pos = buscarProveedor();
            if(pos != -1){
                desasignarProducto(proveedores[pos]);
                for (int i = pos; i < numProveedores - 1; i++) {
                    proveedores[i] = proveedores[i + 1];
                }
                proveedores[numProveedores - 1] = null;
                numProveedores--;
                System.out.println("[ Proveedor Eliminado ]");
            }
        } else {
            System.out.println("* No hay proveedores registrados *");
        }
    }

    public void consultarProveedor() {
        String proveedoresString = "";
        for (int i = 0; i < numProveedores; i++) {
            proveedoresString += proveedores[i] + "\n----------------------------------------------------------------\n";
        }
        escritor.escribirDatosProveedor(proveedoresString);
    }

    public void consultarProveedorEspecifico() {
        int pos = buscarProveedor();
        if(pos !=-1){
            String proveedor = "" + proveedores[pos];
            escritor.escribirDatosProveedor(proveedor);
        }
    }

    public int buscarProveedor() {
        Object[] datos = lector.leerDatosProveedor(false);
        for (int i = 0; i < numProveedores; i++) {
            if (proveedores[i].getNombre().equals(datos[0]) && proveedores[i].getCorreo().equals(datos[1])) {
                return i;
            }
        }
        System.out.println("* No se encontro el proveedor *");
        return -1;
    }

    public Proveedor getProveedor(int i) {
        try {
            return proveedores[i];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("* No se econtro el proveedor *");
            return null;
        }
    }

    public void asignarProducto(Proveedor prov) {
        int pos, opc;
        do {
            opc = lector.leerEntero("Tipo de producto\n[1] No electronico \n[2] Electronico \n[3] Cancelar\nSeleccione la opcion: ");
        } while (opc < 1 || opc > 3);
        System.out.println("Producto a asignar: ");
        switch (opc) {
            case 1:
                pos = controlp.buscarProducto();
                if (pos != -1) {
                    prov.agregarProducto(controlp.getProducto(pos));
                    controlp.getProducto(pos).setProveedor(prov);
                }
                break;
            case 2:
                pos = controlpe.buscarProductoElectronico();
                if (pos != -1) {
                    prov.agregarProducto(controlpe.getProductoElectronico(pos));
                    controlpe.getProductoElectronico(pos).setProveedor(prov);
                }
        }
    }
    public void asignarProducto() {
        int pos2;
        int pos = buscarProveedor(), opc;
        do {
            opc = lector.leerEntero("Tipo de producto\n[1] No electronico \n[2] Electronico\n[3] Cancelar\nSeleccione la opcion: ");
        } while (opc < 1 || opc > 3);
        System.out.println("Producto para asignar: ");
        switch (opc) {
            case 1:
                pos2 = controlp.buscarProducto();
                if (pos2 != -1) {
                    proveedores[pos].agregarProducto(controlp.getProducto(pos2));
                    controlp.getProducto(pos2).setProveedor(proveedores[pos]);
                }
                break;
            case 2:
                pos2 = controlpe.buscarProductoElectronico();
                if (pos2 != -1) {
                    proveedores[pos].agregarProducto(controlpe.getProductoElectronico(pos2));
                    controlpe.getProductoElectronico(pos2).setProveedor(proveedores[pos]);
                }
                break;
        }
    }
    public void desasignarProducto(){
        int pos2;
        int pos = buscarProveedor(), opc;
        do {
            opc = lector.leerEntero("Tipo de producto\n[1] No electronico \n[2] Electronico\n[3] Cancelar\nSeleccione la opcion: ");
        } while (opc < 1 || opc > 3);
        System.out.println("Producto para desasignar: ");
        switch (opc) {
            case 1:
                pos2 = controlp.buscarProducto();
                if (pos2 != -1) {
                    proveedores[pos].eliminarProducto(controlp.getProducto(pos2));
                    controlp.getProducto(pos2).setProveedor(null);
                }
                break;
            case 2:
                pos2 = controlpe.buscarProductoElectronico();
                if (pos2 != -1) {
                    proveedores[pos].eliminarProducto(controlpe.getProductoElectronico(pos2));
                    controlpe.getProductoElectronico(pos2).setProveedor(null);
                }
                break;
        }
    }
    public void desasignarProducto(Proveedor prov){
        for(int i=0;i<prov.getNumProductos();i++){
            prov.getProducto(i).setProveedor(null);
        }
    }
    public void addProveedor(Proveedor p){
        if(numProveedores<proveedores.length){
            proveedores[numProveedores] = p;
            numProveedores++;
        }
    }
    public void cargarDatosProveedor(){
        Proveedor p;
        try{
            FileInputStream fis = new FileInputStream("Proveedor.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);

            while(fis.available()>0){
                p = (Proveedor)ois.readObject();
                addProveedor(p);
            }
            ois.close();
        }catch(FileNotFoundException fe){
            System.out.print(" ");
        }catch(EOFException eo){
            System.err.println(eo);
        }catch(ClassNotFoundException cl){
            System.err.println(cl);
        }catch(IOException ie){
            System.err.println(ie);
        }
    }
    public void generarArchivoProveedor(){
        try{
            File f = new File("Proveedor.obj");
            File f2 = new File("aux4.obj");
                if(numProveedores>0){
                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));
                    for(int i=0;i<numProveedores;i++){
                        oos.writeObject(proveedores[i]);
                    }
                    oos.flush();
                    oos.close();
                    f.delete();
                    f2.renameTo(f);
                }else{
                    f.delete();
                    f2.renameTo(f);
                }
        }catch(FileNotFoundException fe){
            System.err.println(fe);
        }catch(IOException ie){
            System.err.println(ie);
        }
    }
}
