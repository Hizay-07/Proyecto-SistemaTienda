package controlador;
import java.io.*;
import modelo.productos.*;
import modelo.personas.*;
import modelo.operaciones.*;
import vista.*;

public class ControladorVentas {
    private int numPedidos = 0;
    private int numFacturas = 0;
    private Factura[] facturas;
    private Pedido[] pedidos;
    private Menu vista;
    private ControladorTienda controlT;
    private EscritorDatosFactura escritorF = new EscritorDatosFactura();
    private EscritorDatosPedido escritorP = new EscritorDatosPedido();
    private ControladorCliente controlc;
    private ControladorProducto controlp;
    private ControladorProductoElectronico controlpe;
    private EscritorDatosGanancias escritorG = new EscritorDatosGanancias();
    private EscritorDatosInversion escritorI = new EscritorDatosInversion();
    private int minStock;
    private int maxStock;
    public ControladorVentas(){

    }
    public ControladorVentas(Factura[] facturas, Pedido[] pedidos, int minS, int maxS) {
        this.facturas = facturas;
        this.pedidos = pedidos;
        this.minStock = minS;
        this.maxStock = maxS;
    }

    public void addMenu(Menu vista) {
        this.vista = vista;
    }

    public void addControladores(ControladorCliente cl, ControladorProducto cop, ControladorProductoElectronico cpe,
            ControladorTienda ct) {
        controlc = cl;
        controlp = cop;
        controlpe = cpe;
        controlT = ct;
    }

    public void crearFactura() {
        if (numFacturas < facturas.length) {
            int opc, pos, cant;
            Cliente clientetmp = controlc.getCliente();
            if (clientetmp != null) {
                Factura tmp = new Factura(clientetmp, controlT.getTienda());
                do {
                    opc = vista.SubMenuFactura();
                    switch (opc) {
                        case 1:
                            pos = controlp.buscarProducto();
                            if (pos!=-1) {
                                cant = controlp.getLector().leerCantidad();
                                if (controlp.eliminarProducto(pos, cant)) {
                                    Producto aux1 = controlp.getProducto(pos).copiar();
                                    aux1.setNoExistencias(cant);
                                    tmp.agregarProducto(aux1);
                                }
                            }
                            break;
                        case 2:
                            pos = controlpe.buscarProductoElectronico();
                            if (pos != -1) {
                                cant = controlpe.getLector().leerCantidad();
                                if (controlpe.eliminarProductoElectronico(pos, cant)) {
                                    ProductoElectronico aux2 = controlpe.getProductoElectronico(pos).copiar();
                                    aux2.setNoExistencias(cant);
                                    tmp.agregarProducto(aux2);
                                }
                            }
                            break;
                        case 3:
                            if (tmp.getNumProductos() > 0) {
                                facturas[numFacturas] = tmp;
                                numFacturas++;
                            } else {
                                System.out.println("* La factura no pudo ser creada *");
                            }
                            break;
                    }
                } while (opc != 3 && opc != 4);
            }
        } else {
            System.out.println("* No hay espacio para mas facturas *");
        }
    }

    public void crearPedido() {
        if (numPedidos < pedidos.length) {
            int opc, pos, cant;
            Pedido tmp = new Pedido();
            opc = vista.SubMenuPedido();
            switch (opc) {
                case 1:
                    pos = controlp.buscarProducto();
                    if (pos != -1) {
                        if (controlp.getProducto(pos).getProveedor() != null) {
                            cant = controlp.getLector().leerCantidad();
                            if (controlp.agregarProducto(pos, cant)) {
                                Producto aux1 = controlp.getProducto(pos).copiar();
                                aux1.setNoExistencias(cant);
                                tmp.addProducto(aux1);
                            }
                        } else {
                            System.out.println("* Este producto no cuenta con un proveedor aun *");
                        }
                    }
                    break;
                case 2:
                    pos = controlpe.buscarProductoElectronico();
                    if (pos != -1) {
                        if (controlpe.getProductoElectronico(pos).getProveedor() != null) {
                            cant = controlpe.getLector().leerCantidad();
                            if (controlpe.agregarProductoElectronico(pos, cant)) {
                                ProductoElectronico aux2 = controlpe.getProductoElectronico(pos).copiar();
                                aux2.setNoExistencias(cant);
                                tmp.addProducto(aux2);
                            }
                        } else {
                            System.out.println("* Este producto no cuenta con un proveedor aun *");
                        }
                    }
                    break;
            }
            if (tmp.getProducto() != null) {
                pedidos[numPedidos] = tmp;
                numPedidos++;
            } else {
                System.out.println("* No se creo el pedido *");
            }
        } else {
            System.out.println("* No hay espacio para mas pedidos *");
        }
    }

    public void surtirTienda(){
        for(int i=0;i<controlp.getNumProductos();i++){
            if(controlp.getProducto(i).getProveedor()==null){
                System.out.println("El producto "+controlp.getProducto(i).getNombre()+" no cuenta con proveedor");
            }else if(controlp.getProducto(i).getNoExistencias()==maxStock){
                System.out.println("El producto "+controlp.getProducto(i).getNombre()+" tiene stock lleno");
            }else{
                int cant=0;
                cant = maxStock - controlp.getProducto(i).getNoExistencias();
                crearPedidoNoElectronico(i, cant);
            }
        }
        for(int i=0;i<controlpe.getNumProductos();i++){
            if(controlpe.getProductoElectronico(i).getProveedor()==null){
                System.out.println("El producto "+controlpe.getProductoElectronico(i).getNombre()+" no cuenta con proveedor");
            }else if(controlpe.getProductoElectronico(i).getNoExistencias()==maxStock){
                System.out.println("El producto "+controlp.getProducto(i).getNombre()+" tiene stock lleno");
            }else{
                int cant=0;
                cant = 10 - controlpe.getProductoElectronico(i).getNoExistencias();
                crearPedidoElectronico(i, cant);
            }
        }
        System.out.println("TIENDA SURTIDA");
    }
    public boolean crearPedidoNoElectronico(int pos, int cant){
        if(numPedidos<pedidos.length){
        Producto aux= controlp.getProducto(pos).copiar();
        aux.setNoExistencias(cant);
        Pedido tmp= new Pedido();
        tmp.addProducto(aux);
        pedidos[numPedidos]=tmp;
        numPedidos++;

        controlp.agregarProducto(pos, cant);
        return true;
        }else{
            System.out.println("* No hay espacio para pedidos automaticos *");
            return false;
        }
    }
    public boolean crearPedidoElectronico(int pos, int cant){
        if(numPedidos<pedidos.length){
        ProductoElectronico aux= controlpe.getProductoElectronico(pos).copiar();
        aux.setNoExistencias(cant);
        Pedido tmp= new Pedido();
        tmp.addProducto(aux);
        pedidos[numPedidos]=tmp;
        numPedidos++;

        controlpe.agregarProductoElectronico(pos, cant);
        return true;
        }else{
            System.out.println("* No hay espacio para pedidos automaticos *");
            return false;
        }
    }
    public void consultarFacturas() {
        String facturaString = "";
        if (numFacturas > 0) {
            for (int i = 0; i < numFacturas; i++) {
                facturaString += facturas[i] + "\n----------------------------------------------------------------\n";
            }
            escritorF.EscribirDatosFactura(facturaString);
        } else {
            System.out.println("*No hay facturas por mostrar*");
        }
    }

    public void consultarPedidos() {
        String pedidoString = "";
        if (numPedidos > 0) {
            for (int i = 0; i < numPedidos; i++) {
                pedidoString += pedidos[i] + "\n----------------------------------------------------------------\n";
            }
            escritorP.EscribirDatosPedido(pedidoString);
        } else {
            System.out.println("*No hay pedidos por mostrar*");
        }
    }

    public void perdidasTotales() {
        float f = 0;
        if (numPedidos >= 1) {
            for (int i = 0; i < numPedidos; i++) {
                f = f + pedidos[i].calcularTotal();
            }
        } else {
            f = 0;
        }
        escritorI.escribirTotalCompras(f);
    }

    public void gananciasTotales() {
        float f = 0;
        if (numFacturas >= 1) {
            for (int i = 0; i < numFacturas; i++) {
                f = f + facturas[i].calcularTotal();
            }
        } else {
            f = 0;
        }
        escritorG.escribirGanancias(f);
    }
    public void addFactura(Factura f){
        if(numFacturas<facturas.length){
            facturas[numFacturas] = f;
            numFacturas++;
        }
    }
    public void cargarDatosFacturas(){
        Factura f;
        try{
            FileInputStream fis = new FileInputStream("Facturas.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);

            while(fis.available()>0){
                f = (Factura)ois.readObject();
                addFactura(f);
            }
            ois.close();
        }catch(FileNotFoundException fi){
            System.err.print(" ");
        }catch(EOFException eo){
            System.err.println(eo);
        }catch(IOException ie){
            System.err.println(ie);
        }catch(ClassNotFoundException cl){
            System.err.println(cl);
        }
    }
    public void generarArchivoFacturas(){
        try{
            File f = new File("Facturas.obj");
            File f2 = new File("aux5.obj");
            if(numFacturas>0){
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));

                for(int i=0;i<numFacturas;i++){
                    oos.writeObject(facturas[i]);
                }
                oos.flush();
                oos.close();
                f.delete();
                f2.renameTo(f);
            }else{
                f.delete();
                f2.renameTo(f);
            }
        }catch(IOException ie){
            System.err.println(ie);
        }
    }
    public void addPedido(Pedido p){
        if(numPedidos<pedidos.length){
            pedidos[numPedidos] = p;
            numPedidos++;
        }
    }
    public void cargarDatosPedidos(){
        Pedido p;
        try{
            FileInputStream fis = new FileInputStream("Pedidos.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);

            while(fis.available()>0){
                p = (Pedido)ois.readObject();
                addPedido(p);
            }
            ois.close();
        }catch(FileNotFoundException fe){
            System.err.print(" ");
        }catch(EOFException eo){
            System.err.print(eo);
        }catch(IOException ie){
            System.err.print(ie);
        }catch(ClassNotFoundException cl){
            System.err.print(cl);
        }
    }
    public void generarArchivoPedidos(){
        try{
            File f = new File("Pedidos.obj");
            File f2 = new File("aux6.obj");
            if(numPedidos>0){
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));

                for(int i=0;i<numPedidos;i++){
                    oos.writeObject(pedidos[i]);
                }
                oos.flush();
                oos.close();
                f.delete();
                f2.renameTo(f);
            }else{
                f.delete();
                f2.renameTo(f);
            }
        }catch(IOException ie){
            System.err.println(ie);
        }
    }
}
