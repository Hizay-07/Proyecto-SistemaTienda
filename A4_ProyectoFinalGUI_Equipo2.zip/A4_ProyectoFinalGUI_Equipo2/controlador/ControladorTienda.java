package controlador;
import vista.*;
import modelo.*;
public class ControladorTienda{
    private Menu vista;
    private Tienda tienda;
    private EscritorDatosTienda escritor= new EscritorDatosTienda();
    private LectorDatosTienda lector= new LectorDatosTienda();
    public ControladorTienda(Tienda tienda){
        this.tienda=tienda;
    }
    public Tienda getTienda(){
        return tienda;
    }
    public void addVista(Menu vista){
        this.vista=vista;
    }
    public void asignarNombre(){
        String nombre="Tienda FEI";
        tienda.setNombre(nombre);
    }
    public void consultarTienda(){
        String tiendaString=""+tienda;
        escritor.escribirDatosTienda(tiendaString);
    }
}