package controlador;
import java.io.*;
import vista.*;
import modelo.productos.*;

public class ControladorProducto {
    private Menu vista;
    private Producto[] productos;
    private int numProductos = 0;
    private int minStock;
    private int maxStock;

    private LectorDatosProducto lector = new LectorDatosProducto();
    private EscritorDatosProducto escritor = new EscritorDatosProducto();
    private VentanaProducto lectorp;
    ControladorVentas controlv= new ControladorVentas();

    public LectorDatosProducto getLector() {
        return lector;
    }

    public ControladorProducto(Producto[] productos, int minS, int maxS) {
        this.productos = productos;
        this.minStock = minS;
        this.maxStock = maxS;
    }

    public void addVista(Menu vista) {
        this.vista = vista;
    }
    public void addControlador(ControladorVentas cv){
        controlv= cv;
    }
    public void addVentana(VentanaProducto lectorp){
        this.lectorp=lectorp;
    }
    public int getNumProductos() {
        return numProductos;
    }
    public void agregarProducto(String n,String c,float pv,int d,String ds, int ca){
        Producto tmp= new Producto(n,c,pv,d,ds,ca);
        agregarProducto(tmp,ca);
    }
    public void agregarProducto(Producto np, int cant) {
        if (numProductos < productos.length) {
            int pos = buscarProducto(np);
            if (pos != -1) {
                if (productos[pos].getNoExistencias() + (int) cant<= maxStock) {
                    if ((int) cant> 0){
                        productos[pos].setNoExistencias(productos[pos].getNoExistencias() + (int) cant);
                        System.out.println("[ Producto agregado ]");
                    }
                } else {
                    System.out.println("* El producto cuenta con " + productos[pos].getNoExistencias() + " existencias *");
                    System.out.println("* Procura no sobrepasar el stock maximo de " + maxStock + " *");
                }
            } else {
                if((int)cant <= maxStock  && (int)cant >0){
                    productos[numProductos] = np;
                    numProductos++;  
                }else{
                    System.out.println("* Recuerda que el maximo por producto son "+maxStock+" *");
                } 
            }
        } else {
            System.out.println("* Inventario lleno *");
        }
    }

    public void eliminarProducto() {
        int pos = buscarProducto();
        if (pos != -1) {
            if(productos[pos].getProveedor()!=null)
            productos[pos].getProveedor().eliminarProducto(productos[pos]);
            for(int i=pos;i<numProductos-1;i++){
                productos[pos]= productos[pos+1];
            }
            productos[numProductos]=null;
            numProductos--;
            System.out.println("[Producto Eliminado]");
        }
    }

    public void modificarProducto() {
        int pos = buscarProducto();
        if (pos != -1) {
            Object[] modificaciones = vista.mostrarSubMenuModificaciones(1);
            switch ((int) modificaciones[0]) {
                case 1: productos[pos].setNombre((String) modificaciones[1]); break;
                case 2: productos[pos].setCodigo((String) modificaciones[1]); break;
                case 3: productos[pos].setPrecioVenta(Float.parseFloat((String) modificaciones[1])); break;
                case 4: productos[pos].setDescuento(Integer.parseInt((String) modificaciones[1])); break;
                case 5: productos[pos].setDescripcion((String) modificaciones[1]); break;
            }
        }
    }

    public int buscarProducto() {
        Object[] datos = lector.leerDatosBusqueda();
        for (int i = 0; i < numProductos; i++) {
            if (productos[i].getNombre().equals(datos[0]) && productos[i].getCodigo().equals(datos[1])) {
                return i;
            }
        }
        System.out.println("* No se encontro el producto *");
        return -1;
    }
    public int buscarProducto(String n, String cod){
        for(int i=0;i<numProductos;i++){
            if(productos[i].getNombre().equals(n) && productos[i].getCodigo().equals(cod)){
                return i;
            }
        }
        return -1;
    }
    public void consultarProducto() {
        String productoString = "";
        for (int i = 0; i < numProductos; i++) {
            productoString += "\n" + productos[i]+ "\n----------------------------------------------------------------\n";
        }
        escritor.escribirDatosProductos(productoString);
    }

    public void consultarProductoEspecifico() {
        int pos = buscarProducto();
        if (pos != -1) {
            String producto = productos[pos]+ "\n----------------------------------------------------------------\n";
            escritor.escribirDatosProductos(producto);
        }
    }

    public int buscarProducto(Producto p) {
        for (int i = 0; i < numProductos; i++) {
            if (p.equals(productos[i])) {
                return i;
            }
        }
        return -1;
    }

    public boolean eliminarProducto(int pos, int cant) {
        if (pos != -1) {
            if (productos[pos].getNoExistencias() - cant >= 0) {
                productos[pos].setNoExistencias(productos[pos].getNoExistencias() - cant);
                if(productos[pos].getNoExistencias() <= minStock){
                    llamarPedidoAutomatico(pos);
                }
                return true;
            } else {
                System.out.println("* No contamos con suficientes existencias *");
                System.out.println("* Contamos con: " + productos[pos].getNoExistencias() + " *");
                System.out.println("* Y usted quiere retirar: " + cant + " *");
            }
        }
        return false;
    }
    public boolean agregarProducto(int pos, int cant) {
       if(productos[pos].getNoExistencias() + cant <= maxStock){
        productos[pos].setNoExistencias(productos[pos].getNoExistencias()+cant);
        return true;
       }
       System.out.println("* Se esta excediendo el limite por de existencias *");
       System.out.println("* Contamos con: "+productos[pos].getNoExistencias()+" *");
       System.out.println("* Y usted quiere agregar: "+ cant +" *");
       return false;
    }
    public Producto getProducto(int i) {
        try {
            return productos[i];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("* No se econtro el producto *");
            return null;
        }
    }
    public void llamarPedidoAutomatico(int pos){
        System.out.println("* Se sobrepaso el stock minimo de "+minStock+" *");
        if(productos[pos].getProveedor() != null){
            int faltante= maxStock - productos[pos].getNoExistencias();
            if(controlv.crearPedidoNoElectronico(pos, faltante))
            System.out.println("* Se realizo un pedido automatico de "+productos[pos].getNombre()+" <"+productos[pos].getCodigo()+"> de "+faltante+" *");
        }else{
            System.out.println("* No se pudo hacer un pedido automatico *");
            System.out.println("* Por favor, asignar un proveedor al producto *");
            
        }

    }
    public void agregarProducto(Producto p){
        if(numProductos<productos.length){
            productos[numProductos] = p;
            numProductos++;
        }
    }
    public void cargarDatosProducto(){
        Producto p;
        try{
            FileInputStream fis = new FileInputStream("Productos.obj");
            ObjectInputStream ois = new ObjectInputStream(fis);

            while(fis.available()>0){
                p = (Producto)ois.readObject();
                agregarProducto(p);
            }
            ois.close();
        }catch(FileNotFoundException fe){
            System.err.print(" ");
        }catch(EOFException eo){
            System.err.println(eo);
        }catch(IOException ie){
            System.err.println(ie);
        }catch(ClassNotFoundException cl){
            System.err.println(cl);
        }
    }
    public void guardarDatosProductos(){
        File f = new File("Productos.obj");
        File f2 = new File("aux2.obj");
        try{
            if(numProductos>0){
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f2, false));
                for(int i=0;i<numProductos;i++){
                    oos.writeObject(productos[i]);
                }
                oos.flush();
                oos.close();
                f.delete();
                f2.renameTo(f);
            }else{
                f.delete();
                f2.renameTo(f);
            }
        }catch(IOException ie){
            System.err.println(ie);
        }
    }
}