package modelo.productos;

import java.io.Serializable;

import modelo.personas.*;

/***************************************************
 * Autor: Ivan Rodriguez Franco
 * Fecha de elaboracion: 02/04/23
 * Fecha de modificacion: 18/04/23
 ***************************************************/

public class Producto implements Iva, Serializable {
  protected String nombre;
  protected String codigo;
  protected float precioVenta;
  protected int descuento;
  protected String descripcion;
  protected int noExistencias;
  protected Proveedor proveedor;

  public Producto() {
  }

  public Producto(String n, String c, float pv, int d, String ds, int ne) {
    nombre = n;
    codigo = c;
    precioVenta = pv;
    descuento = d;
    descripcion = ds;
    noExistencias = ne;
  }

  public Producto(Producto aCopiar) {
    this.nombre = aCopiar.nombre;
    this.codigo = aCopiar.codigo;
    this.precioVenta = aCopiar.precioVenta;
    this.descuento = aCopiar.descuento;
    this.descripcion = aCopiar.descripcion;
    this.proveedor = aCopiar.proveedor;
  }

  public Producto copiar() {
    return new Producto(this);
  }

  public String getNombre() {
    return nombre;
  }

  public String getCodigo() {
    return codigo;
  }

  public float getPrecioVenta() {
    return precioVenta;
  }

  public int getDescuento() {
    return descuento;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public int getNoExistencias() {
    return noExistencias;
  }

  public Proveedor getProveedor() {
    return proveedor;
  }

  public float calcularIVA() {
    return precioVenta * IVA;
  }

  public float calcularDescuento() {
    return precioVenta * descuento / 100;
  }

  public float calcularPrecioFinal() {
    return precioVenta + calcularIVA() - calcularDescuento();
  }

  public void setNombre(String n) {
    nombre = n;
  }

  public void setCodigo(String c) {
    codigo = c;
  }

  public void setPrecioVenta(float pv) {
    precioVenta = pv;
  }

  public void setDescuento(int d) {
    descuento = d;
  }

  public void setDescripcion(String ds) {
    descripcion = ds;
  }

  public void setNoExistencias(int ne) {
    noExistencias = ne;
  }

  public void setProveedor(Proveedor p) {
    proveedor = p;
  }

  public String toString() {
    String proveedorString;
    if (proveedor == null) {
      proveedorString = "Sin proveedor";
    } else {
      proveedorString = proveedor.getNombre();
    }
    return "No. Existencias: " + noExistencias + "\n" + nombre + " <" + codigo + ">\tPrecio: " + precioVenta
        + "\t IVA: " + calcularIVA() + "$\t Descuento: "
        + descuento + "%\n" + "\n::" + descripcion + "\n-Proveedor: "
        + proveedorString;
  }

  public boolean equals(Object obj) {
    boolean retorno = false;
    if (obj instanceof Producto) {
      Producto tmp = (Producto) obj;
      if (this.nombre.equals(tmp.nombre)) {
        if (this.codigo.equals(tmp.codigo)) {
          if (this.precioVenta == tmp.precioVenta) {
            if (this.descuento == tmp.descuento) {
              if (this.descripcion.equals(tmp.descripcion)) {
                retorno = true;
              }
            }
          }
        }
      }
    }
    return retorno;
  }
}
