package modelo.productos;

/***************************************************
*Autor: Ivan Rodriguez Franco
*Fecha de elaboracion: 02/04/23
*Fecha de modificacion: 18/04/23
***************************************************/

public interface Iva{
  public static final float IVA=0.16F;
  float calcularIVA();
}
    

    
