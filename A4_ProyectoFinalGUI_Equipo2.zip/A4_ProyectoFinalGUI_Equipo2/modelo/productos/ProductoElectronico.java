package modelo.productos;

/***************************************************
 * Autor: Ivan Rodriguez Franco
 * Fecha de elaboracion: 03/04/23
 * Fecha de modificacion: 18/04/23
 ***************************************************/

public class ProductoElectronico extends Producto {
	private int numSerie;

	public ProductoElectronico() {
	}

	public ProductoElectronico(String n, String c, float pv, int d, String ds, int ne, int ns) {
		super(n, c, pv, d, ds, ne);
		numSerie = ns;
	}

	public ProductoElectronico(ProductoElectronico aCopiar) {
		this.nombre = aCopiar.nombre;
		this.codigo = aCopiar.codigo;
		this.precioVenta = aCopiar.precioVenta;
		this.descuento = aCopiar.descuento;
		this.descripcion = aCopiar.descripcion;
		this.proveedor = aCopiar.proveedor;
		this.numSerie = aCopiar.numSerie;
	}
	public ProductoElectronico copiar(){
		return new ProductoElectronico(this);
	}

	public int getNumSerie() {
		return numSerie;
	}

	public void setNumSerie(int ns) {
		numSerie = ns;
	}

	public String toString() {
		return super.toString() + "\nNo. Serie: " + numSerie;
	}

	public boolean equals(Object obj) {
		boolean retorno = false;
		if (obj instanceof ProductoElectronico) {
			ProductoElectronico tmp = (ProductoElectronico) obj;
			if (super.equals(tmp)) {
				if (this.numSerie == tmp.numSerie) {
					retorno = true;
				}
			}
		}
		return retorno;
	}
}
