package modelo;

import java.io.Serializable;

/***************************************************
*Autor: Mario Miguel Limon Cabrera
*Fecha de elaboracion: 01/04/23
*Fecha de modificacion: 17/04/23
***************************************************/
public class Tienda implements Serializable{
  private String nombre;
  private String rfc;
  
  public Tienda(){
  }
  public Tienda(String n,String r){
 	nombre=n;
	rfc=r;
  }
  public String getNombre(){
	return nombre;
  }
  public String getRfc(){
	return rfc;	
  }
  public void setNombre(String n){
	nombre=n;
  }
  public void setRfc(String r){
	rfc=r;
  }
  public String toString(){
    return nombre;
  }

}















    
