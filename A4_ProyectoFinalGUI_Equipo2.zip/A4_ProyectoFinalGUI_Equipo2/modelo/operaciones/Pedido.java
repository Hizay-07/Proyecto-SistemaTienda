package modelo.operaciones;    
import java.io.Serializable;

import modelo.personas.*;
import modelo.productos.*;

/***************************************************
*Autor: Christopher Vasquez Zapata
*Fecha de elaboracion: 05/04/23
*Fecha de modificacion: 21/04/23
***************************************************/

public class Pedido implements Serializable{
  private Producto producto;
  private Proveedor proveedor;
  public Pedido(){
  }
  public Producto getProducto(){
	return producto;
  }
  public void setProducto(Producto p){
	producto=p;
  } 
  public Proveedor getProveedor(){
	return proveedor;
  }
  public void setProveedor(Proveedor p){
	proveedor=p;
  }
  public void addProducto(Producto p){
	producto=p;
	proveedor=p.getProveedor();
  }
  public float calcularTotal(){
	return producto.getPrecioVenta()*producto.getNoExistencias();
  }
  public int contarProducto(){
	return producto.getNoExistencias();
  }
  public String toString(){
	String infoProveedor="\nProveedor: "+proveedor.getNombre()+"\nCorreo:"+proveedor.getCorreo()+"\nTel: "+proveedor.getTelefono();
	String infoProducto="\nPedido del Producto: "+producto.getNombre()+" \tPor la cantidad de "+producto.getNoExistencias();
	String infoPrecio="\nPrecio final: "+calcularTotal();
	return infoProducto+infoProveedor+infoPrecio;
  }
}
    

    

    
