package modelo.operaciones;

import modelo.productos.*;
import modelo.personas.*;

import java.io.Serializable;

import modelo.Tienda;

/***************************************************
 * Autor: Christopher Vasquez Zapata
 * Fecha de elaboracion: 07/04/23
 * Fecha de modificacion: 21/04/23
 ***************************************************/

public class Factura implements Serializable {
	public static int maxProducto = 10;
	private Producto[] productos = new Producto[maxProducto];
	private Cliente cliente;
	private Tienda tienda;
	private int numProductos = 0;

	public Factura() {
	}

	public Factura(Cliente c, Tienda t) {
		cliente = c;
		tienda = t;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente c) {
		cliente = c;
	}

	public Producto getProducto(int i) {
		return productos[i];
	}

	public void setProducto(int i, Producto p) {
		productos[i] = p;
	}

	public int getNumProductos() {
		return numProductos;
	}

	public void setNumProductos(int np) {
		numProductos = np;
	}

	public Tienda getTienda() {
		return tienda;
	}

	public void setTienda(Tienda t) {
		tienda = t;
	}

	public void eliminarProducto(int pos) {
		for (int i = pos; i < numProductos - 1; i++) {
			productos[i] = productos[i + 1];
		}
		numProductos--;
	}

	public void agregarProducto(Producto p) {
		if (numProductos <= maxProducto) {
			int pos = buscarProducto(p);
			if (pos != -1) {
				productos[pos].setNoExistencias(productos[pos].getNoExistencias() + p.getNoExistencias());
			} else {
				productos[numProductos] = p;
				numProductos++;
			}
		} else {
			System.out.println("*No se pueden agregar mas de 10 productos*");
			System.out.println("llevas " + numProductos + " productos diferentes");
		}
	}
	public int buscarProducto(Producto p) {
		for (int i = 0; i < numProductos; i++) {
			if (productos[i].equals(p)) {
				return i;
			}
		}
		return -1;
	}
	public float calcularTotal() {
		float total = 0;
		for (int i = 0; i < numProductos; i++) {
			total = total + productos[i].calcularPrecioFinal() * productos[i].getNoExistencias();
		}
		return total;
	}

	public String listaProductos() {
		String lista = "";
		for(int i=0; i<numProductos;i++){
			lista+=productos[i].getNoExistencias()+"\t"+productos[i].getNombre()+"\t"+productos[i].calcularPrecioFinal()+"\t"+productos[i].calcularPrecioFinal()*productos[i].getNoExistencias()+"\n";
		}
		return lista;
	}

	public String toString() {
		String infoTienda = " \t" + tienda.getNombre() + "\n";
		String infoCliente = "Cliente: " + cliente.getNombre() + "\nCorreo: " + cliente.getCorreo() + "\nDomicilio: "+ cliente.getDireccion() + "\nRFC: " + cliente.getRFC() + "\n";
		String infoProducto = listaProductos() + "\n";
		String linea = "----------------------------------------------------------------------------------------\n";
		String titulo = "Cant\tProducto\t\tPrecio unit\tPrecio neto\n";
		String cantidad = "Productos: " + numProductos + "\t\t\t\t\t\tTotal: " + calcularTotal() + "$\n";
		return "\n" + linea + infoTienda + linea + infoCliente + linea + titulo + linea + infoProducto + linea
				+ cantidad + linea;
	}
}
