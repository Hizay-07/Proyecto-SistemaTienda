package modelo.personas;
   
/***************************************************
*Autor: Oscar Hizay Apodaca Garcia
*Fecha de elaboracion: 04/04/23
*Fecha de modificacion: 20/04/23
***************************************************/
 
public class Cliente extends Persona{
  private String direccion;
  private String rfc;
  public Cliente(){
  }
  public Cliente(String n, String c, String d, String rf){
	super(n,c);
  	direccion=d;
 	rfc=rf;
  }
  public String getDireccion(){
	return direccion;
  }
  public void setDireccion(String d){
	direccion=d;
  }
  public String getRFC(){
	return rfc;
  }
  public void setRFC(String rf){
	rfc=rf;
  }
  public String toString(){
	return super.toString()+"\nDireccion: "+direccion+"\tRFC: "+rfc;
  }
  public boolean equals(Object obj){
	boolean retorno=false;
	if(obj instanceof Cliente){
		Cliente tmp=(Cliente)obj;
		if(super.equals(tmp)){
			if(this.direccion.equals(tmp.direccion)){
				if(this.rfc.equals(tmp.rfc)){		
					retorno=true;
				}
			}
		}
	}
	return retorno;
  }
}
    

    
