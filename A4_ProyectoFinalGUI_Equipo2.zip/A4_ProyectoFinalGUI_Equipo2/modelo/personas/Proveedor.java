package modelo.personas;
import modelo.productos.*;

/***************************************************
*Autor: Oscar Hizay Apodaca Garcia
*Fecha de elaboracion: 04/04/23
*Fecha de modificacion: 21/04/23
***************************************************/
    
public class Proveedor extends Persona{
  private String telefono;
  private Producto[] productos=new Producto[10];
  private int numProductos=0;
  public Proveedor(){
  }
  public Proveedor(String n, String c, String tel){
	super(n,c);
 	telefono=tel;
  }
  public String getTelefono(){
	return telefono;
  }
  public void setTelefono(String tel){
	telefono=tel;
  }
  public Producto getProducto(int i){
	return productos[i];	
  }
  public void setProducto(Producto p,int i){
  	productos[i]=p;
  }
  public boolean comprobarRepeticion(Producto p){
	for(int i=0;i<numProductos;i++){
		if(productos[i].equals(p))
		return true;
	}
	return false;
  }
  public int getNumProductos(){
	return numProductos;
  }
  public void setNumProductos(int np){
	numProductos= np;
  }
  public void agregarProducto(Producto p){
	if(numProductos<10){
		if(!(comprobarRepeticion(p))){
			productos[numProductos]=p;
		    numProductos++;	
		}else{
			System.out.println("* El producto ya esta asignado *");
		}
	}
	else{
		System.out.println("No hay espacio para mas productos");
	}
  }
  public void eliminarProducto(Producto p){
	if(numProductos>0){
		int pos=-1, cont=0;
		while(cont<numProductos){
			if(productos[cont].equals(p)){
				pos=cont;
			}
			cont++;
		}
		if(pos!=-1){
			for(int i=pos;i<numProductos;i++){
				productos[pos]=productos[pos+1];
			}
			productos[numProductos]=null;
			numProductos--;
		}else{
			System.out.println("* Este producto no esta asignado *");
		}

	}
  }
  public String toString(){
	String productosString="\nProductos: ";
	if(numProductos>0){
		for(int i=0;i<numProductos;i++){
			productosString +=productos[i].getNombre()+"\n";
		}
	}else{
		productosString+=" Sin productos asignados";
	}
	return super.toString()+"\tTel: "+telefono+"\tNum. de productos: "+numProductos+productosString;
  }
  public boolean equals(Object obj){
	boolean retorno=false;
	if(obj instanceof Proveedor){
		Proveedor tmp=(Proveedor)obj;
		if(super.equals(tmp)){
			if(this.telefono.equals(tmp.telefono)){
				retorno=true;
			}
		}
	}
	return retorno;
  }
}
    

    

    

    

    
