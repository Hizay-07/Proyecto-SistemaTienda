package modelo.personas;

import java.io.Serializable;

/***************************************************
*Autor: Mario Miguel Limon Cabrera
*Fecha de elaboracion: 03/04/23
*Fecha de modificacion: 19/04/23
***************************************************/

public abstract class Persona implements Serializable{
  protected String nombre;
  protected String correo;
  public Persona(){
  }
  public Persona(String n, String c){
	nombre=n;
 	correo=c;
  }
  public String getNombre(){
	return nombre;
  }
  public void setNombre(String n){
	nombre=n;
  }
  public String getCorreo(){
	return correo;
  }
  public void setCorreo(String c){
 	correo=c;
  }
  public String toString(){
	return "\n"+nombre+"\tCorreo: "+correo;
  }
  public boolean equals(Object obj){
	boolean retorno=false;
	if(obj instanceof Persona){
		Persona tmp=(Persona)obj;
		if(this.nombre.equals(tmp.nombre)){
			if(this.correo.equals(tmp.correo)){
				retorno=true;
			}
		}
	}
	return retorno;
  }
}
    

    
